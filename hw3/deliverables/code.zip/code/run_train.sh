#!/bin/sh
for f in classifier.py autoencoder.py; do
  echo "Running $f"
  python3 $f
done

