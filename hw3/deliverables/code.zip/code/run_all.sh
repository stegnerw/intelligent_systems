#!/bin/sh
python3 dataset.py
./run_train.sh
./run_test.sh

